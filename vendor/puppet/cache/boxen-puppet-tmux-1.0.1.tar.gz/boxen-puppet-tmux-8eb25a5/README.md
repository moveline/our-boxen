# Tmux Puppet Module for Boxen

Tmux!

## Usage

```puppet
include tmux
```

## Required Puppet Modules

* `boxen`
* `homebrew`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
