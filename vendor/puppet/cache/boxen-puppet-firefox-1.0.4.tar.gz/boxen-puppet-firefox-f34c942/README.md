# Firefox

## Usage

```puppet
include firefox
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `rake build` to test it. Check the `script`
directory for other useful tools.
